// Since I am waaaay to lazy, I will just copy-past the complex class from semester 1 here
class Complex 
{
private:
    // Member variables
    int m_real = 0;
    int m_imaginary = 0;

public:
    // Constructors and destructors
    Complex();
    Complex(int, int);
    Complex(const Complex &);

    ~Complex();

    // Getters
    int getRealPart() { return m_real; }
    int getImaginaryPart() { return m_imaginary; }

    // Setters
    void setRealPart(int);
    void setImaginaryPart(int);

    // Utilities
    void print(); // Would have been better if we did an '<<' operator overload

    // The problem does not specify clearly if it want's the number itself
    // to be conjugated or it want's a copy of the conjugated form.
    // I will just conjugate the current number
    void conjugate();

    // Operations
    // It would have been more practical to just overload the arithmetic operators
    Complex add(const Complex &);
    Complex subtract(const Complex &);
    Complex multiply(const Complex &);

    // And add this thing, cuz I need it
    friend bool operator==(const Complex &c1, const Complex &c2)
    {
        return ((c1.m_real == c2.m_real) && (c1.m_imaginary == c2.m_imaginary));
    }
};


#include <iostream>

// Constructors and destructors
Complex::Complex()
{   
    // These are redundunt but I guess I need them for points
    m_real = 0;
    m_imaginary = 0;
}

Complex::Complex(int real, int imaginary)
{
    m_real = real;
    m_imaginary = imaginary;
}
    
Complex::Complex(const Complex &copy)
{
    m_real = copy.m_real;
    m_imaginary = copy.m_imaginary;
}

Complex::~Complex()
{
    // This is a very sad function
    // It does nothing :(
}

// Setters
void Complex::setRealPart(int nReal)
{
    m_real = nReal;
}

void Complex::setImaginaryPart(int nImaginary)
{
    m_imaginary = nImaginary;
}

// Utilities
void Complex::print()
{
    std::cout << m_real;
    if (m_imaginary > 0) // Print '+' if the imaginary part is pozitive
        std::cout << "+";
    if (m_imaginary == 0) // There is no imaginary part to print
        std::cout << "\n";
    else
        std::cout << m_imaginary << "i\n";
}

void Complex::conjugate()
{
    m_imaginary *= -1; // Reverse the imaginary part
}

// Operations

Complex Complex::add(const Complex &aux)
{
    // *Insert comment here not to lose points*
    return Complex(m_real + aux.m_real, m_imaginary + aux.m_imaginary);
}

Complex Complex::subtract(const Complex &aux)
{
    // *Insert comment here not to lose points*
    return Complex(m_real - aux.m_real, m_imaginary - aux.m_imaginary);
}

Complex Complex::multiply(const Complex &aux)
{
    
    /*
     * z1 = a + bi then z2 = c + di
     * z1 · z2 = (a · c − b · d) + (b · c + a · d)i.
     * m_real = a
     * m_imaginary = b
     * aux.m_real = c
     * aux.m_imaginary = d
     */
    return Complex(
        m_real * aux.m_real - m_imaginary * aux.m_imaginary,
        m_imaginary * aux.m_real + m_real * aux.m_imaginary
    );
}

template<typename T>
int array_search(T array[], int count, T elem)
{
    // Loop the array
    for (int i = 0; i < count; ++i)
    {
        // Element found
        if (array[i] == elem)
        {
            return i;
        }
    }

    // Element not found
    return -1;
}

int main()
{
    int a[5] = {1, 2, 3, 4, 5};
    char c[5] = {'a', 'b', 'c', 'd', 'e'};
    // This probably causes a memory leak but meh, whatever
    // Writing a for loop and deleting all of them is hard work
    Complex x[3] = {
        *(new Complex(1, 1)),
        *(new Complex(2, 1)),
        *(new Complex(1, 2))
    };

    std::cout << "3 is in location: " << array_search<int>(a, 5, 3) << "\n";
    std::cout << "6 is in location: " << array_search<int>(a, 5, 6) << "\n";
    std::cout << "d is in location: " << array_search<char>(c, 5, 'd') << "\n";
    std::cout << "g is in location: " << array_search<char>(c, 5, 'g') << "\n";
    std::cout << "2+1i is in location: " << 
        array_search<Complex>(x, 3, *(new Complex(2, 1))) << "\n";
    std::cout << "2+2i is in location: " << 
        array_search<Complex>(x, 3, *(new Complex(2, 2))) << "\n";

    return 0;
}