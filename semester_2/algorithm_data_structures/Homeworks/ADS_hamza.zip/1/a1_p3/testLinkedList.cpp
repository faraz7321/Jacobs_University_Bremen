#include "LinkedList.h"
#include <iostream>

template<typename T>
LinkedList<T>::LinkedList() { }
template<typename T>
LinkedList<T>::LinkedList(const LinkedList<T> &aux)
{
    Node<T> *step = aux.front;
    while (step != nullptr)
    {
        this->push_back(step->elem);
        step = step->next;
    }
}

template<typename T>
void LinkedList<T>::add_first_elem(T elem)
{
    Node<T> *newNode = new Node<T>();
    newNode->elem = elem;
    this->front = newNode;
    this->back = newNode;
    newNode = nullptr;
    delete newNode;
    size = 1;
}

template<typename T>
void LinkedList<T>::push_front(T elem)
{
    if (size == 0)
    {
        this->add_first_elem(elem);
        return;
    }

    // Create and add the node to the list
    Node<T> *newNode = new Node<T>();
    newNode->elem = elem;
    newNode->next = this->front;
    this->front->prev = newNode;
    this->front = newNode;

    size++;
}

template<typename T>
void LinkedList<T>::push_back(T elem)
{
    if (size == 0)
    {
        this->add_first_elem(elem);
        return;
    }

    // Create and add the node to the list
    Node<T> *newNode = new Node<T>();
    newNode->elem = elem;
    newNode->prev = this->back;
    this->back->next = newNode;
    this->back = newNode;

    size++;
}

template<typename T>
int LinkedList<T>::length()
{
    return size;
}

template<typename T>
T LinkedList<T>::get_front()
{
    return this->front->elem;
}
template<typename T>
T LinkedList<T>::get_back()
{
    return this->back->elem;
}

template<typename T>
T LinkedList<T>::pop_front()
{   
    // If there is nothing in the list return an empty thingy
    if (size == 0)
    {
        return *(new T);
    }
    T elem = this->front->elem;

    Node<T> *nodeToRemove = this->front;
    // If there is a second node after this one
    // Set it's previous node as nothing
    if (this->front->next != nullptr)
    {
        this->front->next->prev = nullptr;
    }
    // Set the new front
    this->front = this->front->next;
    // Delete the node
    delete nodeToRemove;

    size--;
    return elem;
}

template<typename T>
T LinkedList<T>::pop_back()
{
    // If there is nothing in the list return an empty thingy
    if (size == 0)
    {
        return *(new T);
    }
    T elem = this->back->elem;

    Node<T> *nodeToRemove = this->back;
    // If there is a node before this one
    // Set it's next node as nothing
    if (this->back->prev != nullptr)
    {
        this->back->prev->next = nullptr;
    }
    // Set the new back
    this->back = this->back->prev;
    // Delete the node
    delete nodeToRemove;

    size--;
    return elem;
}

template<typename T>
LinkedList<T>::~LinkedList()
{
    Node<T> *step = this->front;
    Node<T> *prev = nullptr;
    while (step != nullptr)
    {
        prev = step;
        step = step->next;
        delete prev;
    }
}

template<typename T>
void LinkedList<T>::print()
{
    std::cout << "\n";

    Node<T> *step = this->front;
    while (step != nullptr)
    {
        std::cout << step->elem << " ";
        step = step->next;
    }

    std::cout << "\n";
}

int main()
{
    LinkedList<int> list;
    list.push_front(1);
    list.push_front(2);
    list.push_front(3);
    list.print();
    std::cout << list.get_back() << " " << list.get_front() << " " << list.length() << "\n";
    std::cout << list.pop_back();
    list.push_back(4);
    list.print();

    return 0;
}