

#ifndef H_LINKED_LIST
#define H_LINKED_LIST

template <typename T>
struct Node
{
    T elem;
    Node *next = nullptr, *prev = nullptr;
};

template <typename T>
class LinkedList
{
private:
    // Keep track of the size of the list
    int size = 0;
    // Pointers for the front and the back of the list
    Node<T> *front = nullptr, *back = nullptr;

    void add_first_elem(T elem);

public:
    LinkedList();
    LinkedList(const LinkedList<T> &aux);

    void push_front(T elem);
    void push_back(T elem);
    T get_front(); // Returns the element at the front
    T get_back(); // Returns the element at the back
    T pop_front(); // Returns the element at the front and removes it
    T pop_back(); // Retruns the element at the back and removes it

    int length(); // Returns the number of elements in the list

    void print(); // Prints the list

    ~LinkedList();
};

#endif