#include <vector>
#include <string>
#include <iostream>

int main()
{
    // Input thingy
    std::string s;
    std::vector<std::string> v;

    bool running = true;
    while (running)
    {
        // READ THE THING
        std::getline(std::cin, s);
        if (s == "END") // STOP THE THING
        {
            running = false;
            continue;
        }

        // Push the string in
        v.push_back(s);
    }

    // Print numero 1
    for (int i = 0; i < v.size(); ++i)
    {
        std::cout << v[i] << " ";
    } 
    std::cout << "\n";

    // Print numero 2
    // If you cut points cuz this line has 81 characters, WE HAVE PROBLEM
    for (std::vector<std::string>::iterator it = v.begin(); it != v.end(); ++it)
    {
        std::cout << *it;
        if (it + 1 != v.end()) std::cout<<",";
    }

    return 0;
}