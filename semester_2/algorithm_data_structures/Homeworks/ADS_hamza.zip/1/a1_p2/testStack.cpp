#include "Stack.h"
#include <iostream>

template<typename T>
Stack<T>::Stack() 
{
    this->arr = new T[10];
}

template<typename T>
Stack<T>::Stack(const Stack<T> &aux)
{
    this->arr = new T[aux.size];
    this->entries = aux.entries;
    for (int i = 0; i < aux.entries; ++i)
    {
        this->arr[i] = aux.arr[i];
    }
}

template<typename T>
Stack<T>::Stack(int size)
{
    this->arr = new T[size];
    this->size = size;
}

template<typename T>
bool Stack<T>::push(T element)
{
    // Check if there is space
    if (entries == size)
    {
        return false;
    }

    // Push all the elements 1 step
    for (int i = entries; i > 0; --i)
    {
        arr[i] = arr[i - 1];
    }
    // Put the element in
    arr[0] = element;

    entries++;
    return true;
}

template<typename T>
bool Stack<T>::pop(T &out)
{
    // Check if there is elements in the stack
    if (entries == 0)
    {
        return false;
    }

    // Get the element and push elements 1 step
    out = arr[0];
    for (int i = 0; i < entries - 1; ++i)
    {
        arr[i] = arr[i + 1];
    }
    entries--;

    return true;
}

template<typename T>
T Stack<T>::back()
{
    return arr[0];
}

template<typename T>
int Stack<T>::getNumEntries()
{
    return entries;
}

template<typename T>
Stack<T>::~Stack()
{
    delete arr;
}

template<typename T>
void Stack<T>::print()
{
    std::cout << "\n";
    for (int i = 0; i < entries; ++i)
    {
        std::cout << arr[i] << " ";
    }
    std::cout << "\n";
}

int main()
{
    Stack<int> s(5);
    s.push(2);
    s.push(4);
    s.print();
    int elem;
    s.pop(elem);
    std::cout << elem << "\n";
    std::cout << "There are " << s.getNumEntries() << " entries.\n";
    Stack<int> s2(s);
    s2.push(10);
    s2.print();
    return 0;
}