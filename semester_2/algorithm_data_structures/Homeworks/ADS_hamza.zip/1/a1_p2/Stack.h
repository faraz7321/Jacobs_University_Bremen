

#ifndef H_STACK
#define H_STACK

template<typename T>
class Stack
{
private:
    T* arr = nullptr;
    int entries = 0;
    int size = 10;

public:
    Stack();
    Stack(const Stack<T> &aux);
    Stack(int size);

    bool push(T element);
    bool pop(T& out);

    T back(void);
    int getNumEntries();

    void print();

    ~Stack();    
};

#endif