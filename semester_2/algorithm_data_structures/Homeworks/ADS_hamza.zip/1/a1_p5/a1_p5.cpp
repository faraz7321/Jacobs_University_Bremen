#include <vector>
#include <iostream>
#include <string>

int main()
{
    std::vector<std::string> v;
    std::string s;

    bool running = true;
    while (running)
    {
        std::getline(std::cin, s);
        if (s == "END")
        {
            running = false;
            continue;
        }

        // Put the string in the vector
        v.push_back(s);
    }

    // Swap the 2nd and 5th elements if they are alive and well
    if (v.size() >= 5)
    {
        std::string temp = v[1];
        v[1] = v[4];
        v[4] = temp;
    }
    else
    {
        std::cout << "\na message on the standard output\n";
    }

    // Replace the last element with this thing
    v[v.size() - 1] = "???";

    // Print numero 1
    for (int i = 0; i < v.size() - 1; ++i)
    {
        std::cout << v[i] << ",";
    } 
    std::cout << v[v.size() - 1];
    std::cout << "\n";

    // Print numero 2
    // If you cut points cuz this line has 81 characters, WE HAVE PROBLEM
    for (std::vector<std::string>::iterator it = v.begin(); it != v.end(); ++it)
    {
        std::cout << *it;
        if (it + 1 != v.end()) std::cout<<";";
    }
    std::cout << "\n";

    // Print numero 3
    std::vector<std::string>::iterator it = v.end() - 1;
    while (it != v.begin())
    {
        std::cout << *it << " ";
        it--;
    }
    std::cout << *it;

    return 0;
}