class Node():
    def __init__(self, value):
        self.value = value
        self.right = None
        self.left = None

class BinarySearchTree():
    def __init__(self):
        self.head = None
        self.count = 0
        self.s = ""

    def add(self, elem):
        new_node = Node(elem)
        if self.count == 0:
            self.head = new_node
        else:
            step_node = self.head
            while True:
                val = step_node.value
                if elem < val:
                    if step_node.left is None:
                        step_node.left = new_node
                        break
                    else:
                        step_node = step_node.left
                if elem >= val:
                    # If the elemen is equal to the node's element, I decided to put it in the right
                    # hand side, I could also not put it and return, buuuuut I want to keep it
                    if step_node.right is None:
                        step_node.right = new_node
                        break
                    else:
                        step_node = step_node.right

        self.count += 1
    
    def construct_linked_list(self, linked_list):
        self._infix_construct_linked_list(self.head, linked_list)

    def _infix_construct_linked_list(self, node, linked_list):
        if not node:
            return
        self._infix_construct_linked_list(node.left, linked_list)
        linked_list.push(node.value)
        self._infix_construct_linked_list(node.right, linked_list)

    def _infix_print(self, node):
        if not node:
            return
        self._infix_print(node.left)
        self.s += str(node.value) + " "
        self._infix_print(node.right)

    def __repr__(self):
        self.s = ""
        self._infix_print(self.head)
        return self.s