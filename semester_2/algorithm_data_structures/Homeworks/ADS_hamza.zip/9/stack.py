class Node():
    def __init__(self, value):
        self.value = value
        self.next = None

class Stack():
    def __init__(self, size = -1):
        self.top = None
        self.length = 0
        self.size = size
    
    def isEmpty(self):
        return self.length == 0
    
    def push(self, elem):
        if self.length == self.size:
            print("Stack overflow")
            return
        node = Node(elem)
        node.next = self.top
        self.top = node
        self.length += 1
    
    def pop(self):
        if not self.top:
            return None
        elem = self.top.value
        next_node = self.top.next
        del self.top
        self.top = next_node
        self.length -= 1
        return elem
    
    def reverse(self):
        next, current, prev = None, self.top, None
        while current:
            next = current.next
            current.next = prev
            prev = current
            current = next
        self.top = prev
    
    def __repr__(self):
        s = ""
        n = self.top
        while n:
            s += str(n.value) + " "
            n = n.next
        return s
