from stack import Stack

if __name__ == '__main__':
    numbers = [2, 5, 1, 2, 4, 5, 2]
    s = Stack(5)
    for n in numbers:
        s.push(n)
    
    print(s)
    print(s.pop())
    print(s)


