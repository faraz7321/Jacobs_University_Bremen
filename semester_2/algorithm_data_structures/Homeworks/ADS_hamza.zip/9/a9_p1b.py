# NOT SO EFFICIENT WAY OF MAKING A QUEUE
from stack import Stack

class Queue():
    def __init__(self):
        self.s1 = Stack()
        self.s2 = Stack()
    
    def isEmpty(self):
        return self.s1.length == 0
    
    def push(self, elem):
        self.s1.push(elem)
    
    def pop(self):
        while not self.s1.isEmpty():
            self.s2.push(self.s1.pop())
        elem = self.s2.pop()
        while not self.s2.isEmpty():
            self.s1.push(self.s2.pop())
        
        return elem

    def __repr__(self):
        s = ""
        n = self.s1.top
        while n:
            s = s + " " + str(n.value)
            n = n.next
        s = s[1:]
        return s

if __name__ == '__main__':
    numbers = [2, 5, 1, 2, 4, 5]
    q = Queue()
    for n in numbers:
        q.push(n)
    
    print(q)
    print(q.pop())
    print(q)