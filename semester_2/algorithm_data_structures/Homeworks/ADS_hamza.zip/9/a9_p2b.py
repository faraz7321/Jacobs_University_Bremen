from stack import Stack
from bin_tree import BinarySearchTree as BST

if __name__ == '__main__':
    numbers = [2, 5, 1, 2, 4, 5, 10, 9, 8, 11, 12312, 9, 23]
    # Will use the stack as my linked list, cuz I am lazy af
    t = BST()
    for n in numbers:
        t.add(n)
    
    l = Stack()
    # This function has the algorithm
    t.construct_linked_list(l)
    l.reverse()
    print(l)
    """
    !!!!!!!!!!!!!!!!!!!!!!!!
    TIME COMPLEXITY ANALYSIS THINGY
    So here are the steps:
    We go through the entire BST using the in-fix traversal witch takes O(n).
    The insertion on a linked list is O(1) = C.
    Than we reverse the linked list in O(n).
    So we have O(n * C + n) (or something like that)
    and we get in total O(n)
    !!!!!!!!!!!!!!!!!!!!!!!!
    """