from stack import Stack
from bin_tree import BinarySearchTree as BST

my_list = []

def put_numbers_in_BST(left, right, bst):
    if right < left:
        return
    mid = (left + right) // 2
    bst.add(my_list[mid])
    put_numbers_in_BST(left, mid - 1, bst)
    put_numbers_in_BST(mid + 1, right, bst)

if __name__ == '__main__':
    numbers = list(range(20, 0, -1))
    l = Stack()
    for n in numbers:
        l.push(n)
    
    # Put the numbers in a list, cuz I will need it
    while not l.isEmpty():
        my_list.append(l.pop())
    
    tree = BST()
    put_numbers_in_BST(0, len(my_list) - 1, tree)
    print(tree)
    """
    !!!!!!!!!!!!!!!!!!!!!!!!
    TIME COMPLEXITY ANALYSIS THINGY
    So here are the steps:
    We get all the numbers out of the linked list to a normal array O(n).
    Then we go through that array as we where binary searching a number in a sorted array,
    but at each iteration we add the element that we are at, then we get the left middle and
    right middle and continue on from there. This will take O(n).
    At each step of the recursion, we insert the element to the binary tree, which takes O(log n).
    So we have O(n * log n + n) = O(n * log n)
    By putting elements like this we essentially make the BST as COMPLETE as possible.
    !!!!!!!!!!!!!!!!!!!!!!!!
    """

