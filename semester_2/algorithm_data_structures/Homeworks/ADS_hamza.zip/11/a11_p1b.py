from myMap import Map
from random import choice

MAP_SIZE = 15
NODE_COUNT = 10

def get_nodes(n):
    numbers = list(range(1000))
    l = []
    for i in range(n):
        l.append((choice(numbers), choice(numbers)))
    return l

if __name__ == '__main__':
    m = Map(MAP_SIZE)
    nodes = get_nodes(NODE_COUNT)
    print(nodes)
    for n in nodes:
        m.insertNode(n[0], n[1])
    print(m)