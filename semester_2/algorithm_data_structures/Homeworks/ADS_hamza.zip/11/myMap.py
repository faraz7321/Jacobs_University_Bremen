# I createed this cuz I though there would be removals,
# but there is none.
TOMBSTONE = object()

class Node():
    def __init__(self, key, value):
        self.key = key
        self.value = value

class Map():
    def __init__(self, maxSize):
        self._maxSize = maxSize
        self._arr = [None] * maxSize
        self._currentSize = 0
    
    def _hashCode(self, key):
        # Since I am using python, I am just going to use the built in hash function
        # This is well suited for any data that I can throw in it.
        return hash(key) % self._maxSize

    def insertNode(self, key, value):
        if self._currentSize == self._maxSize:
            raise Exception("YOU ARE PUTTING WAY TO MUCH STUFF IN THIS TABLE")
            return

        # Create the node
        node = Node(key, value)
        # Get the hash value
        hashValue = self._hashCode(key)
        
        # Linear probing
        index = hashValue
        while self._arr[index] is not None:
            index = (index + 1) % self._maxSize
        self._arr[index] = node
        self._currentSize += 1
    
    def get(self, key):
        hashValue = self._hashCode(key)
        start = hashValue
        index = hashValue
        while True:
            node = self._arr[index]
            if node is not None:
                if node.key == key:
                    return node.value
            else: # The key does not exist
                return None
            index = (index + 1) % self._maxSize
            # The key does not exist
            if index == start:
                return None

    def isEmpty(self):
        return self._currentSize == 0

    def __str__(self):
        s = ""
        for n in self._arr:
            if n is not None:
                s += f"(Key: {n.key}, Value: {n.value})\n"
            else:
                s += "None\n"
        return s