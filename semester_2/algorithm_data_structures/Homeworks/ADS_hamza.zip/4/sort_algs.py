def insertion_sort(arr):
    a = arr[:]
    i = 1
    while i < len(arr):
        j = i
        while a[j] < a[j-1]:
            tmp = a[j]
            a[j] = a[j-1]
            a[j-1] = tmp
            j -= 1
            if j == 0 : break
        i += 1
    return a

def merge_sort(k, arr):
    a = arr[:]
    # Base case's
    if len(a) <= k:
        return insertion_sort(a)
    if len(a) == 1:
        return a
    
    mid = len(arr) // 2

    # Divide and conquer
    a1 = merge_sort(k, arr[:mid])
    a2 = merge_sort(k, arr[mid:])

    # Join
    l = []
    i = 0
    j = 0
    while i < len(a1) and j < len(a2):
        if a1[i] < a2[j]:
            l.append(a1[i])
            i += 1
        else:
            l.append(a2[j])
            j += 1
    
    while i < len(a1):
        l.append(a1[i])
        i += 1
    while j < len(a2):
        l.append(a2[j])
        j += 1
    
    return l

if __name__ == '__main__':
    a = merge_sort(4, [4, 2, 3, 2, 1, 5, 6, 1414221, 4124124, 412, 412])
    print(a)