import matplotlib.pyplot as plt
import time

from sort_algs import merge_sort
from a4_p1a import gen_arr

n = 1000
best_case = list(range(0, 500))
worst_case = list(range(499, -1, -1))
avg_case = gen_arr(n)

best_case_times = []
worst_case_times = []
avg_case_times = []

if __name__ == '__main__':
    for k in range(n):
        # The sorting functions create a copy of the array inside of them,
        # so I don't have to worry about passing it as reference or not
        
        # Get time for best case
        start = time.time()
        merge_sort(k, best_case)
        end = time.time()
        delta = end - start
        best_case_times.append(delta)

        # Get time for worst case
        start = time.time()
        merge_sort(k, worst_case)
        end = time.time()
        delta = end - start
        worst_case_times.append(delta)

        # Get time for average case
        start = time.time()
        merge_sort(k, avg_case)
        end = time.time()
        delta = end - start
        avg_case_times.append(delta)
    
    # Plot them
    fig, ax = plt.subplots()
    fig.suptitle('Merge sort with insertion')
    plt.xlabel("K")
    plt.ylabel("Time in miliseconds")

    ax.plot(list(range(n)), best_case_times, color="blue", label="Best case")
    ax.plot(list(range(n)), worst_case_times, color="red", label="Worst case")
    ax.plot(list(range(n)), avg_case_times, color="green", label="Average case")
    ax.legend()
    plt.show()
