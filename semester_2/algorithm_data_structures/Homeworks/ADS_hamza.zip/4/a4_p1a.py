import random
from sort_algs import merge_sort

n = 50
k = n // 2
number_range = list(range(0, 1000))

def gen_arr(n):
    l = []
    for i in range(n):
        l.append(random.choice(number_range))
    
    return l

if __name__ == '__main__':
    arr = gen_arr(n)
    print("Not sorted array: ", end ="")
    print(arr)

    arr = merge_sort(k, arr)
    print("Sorted array: ", end = "")
    print(arr)
