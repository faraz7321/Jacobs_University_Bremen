import time
import matplotlib.pyplot as plt
from random import choice
from heap import Heap

SIZE = 3000
numbers = list(range(10000))
def get_list(l):
    a = []
    for i in range(l):
        a.append(choice(numbers))
    
    return a.copy()

if __name__ == '__main__':
    t1 = []
    t2 = []
    for i in range(SIZE):
        l = get_list(i)

        start = time.time()
        h = Heap()
        for elem in l:
            h.add(elem)
        
        l1 = []
        while h.size() > 0:
            l1 = [h.remove()] + l1
        end = time.time()
        t1.append(end - start)

        start = time.time()
        h = Heap()
        for elem in l:
            h.add(elem)
        
        l2 = []
        while h.size() > 0:
            l2 = [h.wierd_point_b_remove()] + l2
        end = time.time()

        t2.append(end - start)
    
    fig, ax = plt.subplots(1)

    fig.suptitle('Fibonaci numbers')
    plt.xlabel("N")
    plt.ylabel("Time in miliseconds")

    ax.plot(list(range(SIZE)), t1, color="blue", label="Original form")
    ax.plot(list(range(SIZE)), t2, color="red", label="Wierd form")
    ax.legend()
    plt.show()