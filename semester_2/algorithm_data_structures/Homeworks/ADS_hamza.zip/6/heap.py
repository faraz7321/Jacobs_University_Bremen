class Heap:
    
    def __init__(self):
        self.arr = []

    def _swap(self, i, j):
        tmp = self.arr[i]
        self.arr[i] = self.arr[j]
        self.arr[j] = tmp

    def add(self, elem):
        self.arr.append(elem)
        self._heapify(self.size() - 1)

    def _heapify(self, index):
        if index <= 0:
            return
        parent = (index - 1) // 2
        if self.arr[index] > self.arr[parent]:
            self._swap(index, parent)
            self._heapify(parent)

    def remove(self):
        elem = self.arr[0]
        self._swap(0, self.size() - 1)
        self.arr = self.arr[:-1]
        self._sink_the_damn_thing(0)
        return elem

    def wierd_point_b_remove(self):
        elem = self.arr[0]
        self._swap(0, self.size() - 1)
        self.arr = self.arr[:-1]

        self._sink(0)
        self._heapify(self.size() - 1)
        return elem

    def _sink(self, index):
        if index == self.size() - 1:
            return
        
        largest = index
        left = 2 * index + 1
        right = 2 * index + 2

        if left < self.size():
            largest = left
        if right < self.size():
            if self.arr[largest] < self.arr[right]:
                largest = right
        
        if largest != index:
            self._swap(largest, index)
            self._sink(largest)

    def _sink_the_damn_thing(self, index):
        if index == self.size() - 1:
            return
        largest = index
        left = 2 * index + 1
        right = 2 * index + 2
        if left < self.size() and self.arr[left] > self.arr[largest]:
            largest = left

        if right < self.size() and self.arr[right] > self.arr[largest]:
            largest = right

        if largest != index:
            self._swap(index, largest)
            self._sink_the_damn_thing(largest)

    def size(self):
        return len(self.arr)

    def print(self):
        i = 1
        l = 2
        for elem in self.arr:
            print(elem, end=' ')
            i += 1
            if i == l:
                print('')
                l *= 2

if __name__ == '__main__':
    h = Heap()
    from random import choice
    numbers = list(range(500))
    for i in range(16):
        n = choice(numbers)
        print(n, end=' ')
        h.add(n)
    print()
    h.print()
    print('\n\n\n\n')
    e = h.remove()
    h.print()
    print('\n\n\n')
    print(e)