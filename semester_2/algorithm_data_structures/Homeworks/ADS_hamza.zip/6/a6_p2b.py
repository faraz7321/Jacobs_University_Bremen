from heap import Heap
from random import choice

numbers = list(range(500))

if __name__ == '__main__':
    l = []
    for i in range(500):
        l.append(choice(numbers))
    
    h = Heap()
    for elem in l:
        h.add(elem)
    
    print("Not sorted array")
    print(l, end="\n\n")

    l = []
    while h.size() > 0:
        l = [h.wierd_point_b_remove()] + l
    
    print("Sorted array")
    print(l)