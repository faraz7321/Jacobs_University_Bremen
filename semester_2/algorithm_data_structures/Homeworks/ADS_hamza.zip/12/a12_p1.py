

if __name__ == '__main__':
    A = [8, 3, 6, 50, 10, 8, 100, 30, 60, 40, 80]
    """
    A = []
    while True:
        s = input()
        if s == "":
            break
        A.append(int(s))"""
    n = len(A)

    # Solve
    # D[i] = max(D[i], D[j] + 1 where -1 < j < i)
    D = [1] * n
    for i in range(1, n):
        for j in range(0, i):
            if A[i] > A[j]:
                D[i] = max(D[i], D[j] + 1)

    print(D)
    # Get the solution
    counter = max(D)
    result = []
    for i in range(n - 1, -1, -1):
        if counter == D[i]:
            counter -= 1
            result.append(A[i])
        if counter == 0:
            break

    # Print the solution
    for i in range(len(result) - 1, -1, -1):
        print(result[i], end=' ')