def my_print(l):
    print()
    print("-" * 20)
    for a in l:
        print(a)
    print('-' * 20)

if __name__ == '__main__':
    # Since I can assume that the input will be valid, I'll read each line as
    # string and then transform them to matrix format
    D = []
    original = []
    size = 0
    while True:
        line = input()
        if line == "":
            break
        line = line.split(' ')
        line = list(map(int, line))
        size += 1    
        D.append(line.copy())
        original.append(line.copy())

    # D[i][j] = D[i][j] + max(triagnle[i + 1][j], D[i + 1][j - 1], D[i + 1][j + 1])
    for i in range(size - 2, -1, -1):
        subarr_len = len(D[i])
        for j in range(subarr_len):
            mx = D[i][j]
            middle = 0
            right = 0
            next_line = i + 1
            middle = mx + D[next_line][j]
            if j + 1 < subarr_len:
                right = mx + D[next_line][j + 1]
            D[i][j] = max([middle, right])
    
    # Maximum
    val = D[0][0]
    print(val)
    result = []
    result.append(original[0][0])
    j = 0
    for i in range(1, size):
        val -= result[-1]
        middle = j
        right = j + 1
        if D[i][middle] == val:
            j = middle
            result.append(original[i][middle])
            continue
        if right < len(D[i]):
            if D[i][right] == val:
                j = right
                result.append(original[i][right])
                continue
    
    for i in result:
        print(i, end = ' ')