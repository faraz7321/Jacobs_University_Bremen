from random import choice

def partition_hoare(A, left, right):
    pivot = A[left]
    i = left - 1
    j = right + 1
    while True:
        i += 1
        while A[i] < pivot:
            i += 1
        j -= 1
        while A[j] > pivot:
            j -= 1
        
        if i >= j: return j
        A[i], A[j] = A[j], A[i]

def median_of_3(A, left, right):
    mid = (left + right) // 2
    if A[left] > A[mid]:
        A[mid], A[left] = A[left], A[mid]
    if A[left] > A[right]:
        A[left], A[right] = A[right], A[left]
    if A[mid] > A[right]:
        A[mid], A[right] = A[right], A[mid]
    
    A[mid], A[right] = A[right], A[mid]

def quick_sort_median_of_3(A, left, right):
    if left < right:
        median_of_3(A, left, right)
        pivot = partition_hoare(A, left, right)
        quick_sort_median_of_3(A, left, pivot - 1)
        quick_sort_median_of_3(A, pivot + 1, right)

numbers = list(range(1000))
def get_arr(length):
    L = []
    for i in range(length):
        L.append(choice(numbers))
    return L.copy()

if __name__ == '__main__':
    A = get_arr(40)
    print("Not sorted array:")
    print(A)
    quick_sort_median_of_3(A, 0, len(A) - 1)
    print("Sorted array:")
    print(A)