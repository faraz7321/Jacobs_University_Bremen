from random import choice

numbers = list(range(1000))

def get_arr(length):
    L = []
    for i in range(length):
        L.append(choice(numbers))
    return L.copy()

def partition(A, left, right):
    # Bring the second element to the end
    # of the partition
    A[left + 1], A[right] = A[right], A[left + 1]
    # Arrange the pivots
    if A[left] > A[right]:
        A[left], A[right] = A[right], A[left]
    
    # "Pivotify" for the right pivot, excluding the left pivot
    pivot = A[right]
    i = left
    for j in range(left + 1, right):
        if A[j] < pivot:
            i += 1
            A[i], A[j] = A[j], A[i]
    A[i + 1], A[right] = A[right], A[i + 1]

    right_pos = i + 1

    # "Pivotify" for the left pivot,
    # but only until where the right pivot is located
    pivot = A[left]
    k = right_pos
    for j in range(right_pos - 1, left, -1):
        if A[j] > pivot:
            k -= 1
            A[k], A[j] = A[j], A[k]
    A[k - 1], A[left] = A[left], A[k - 1]

    left_pos = k - 1
    
    return left_pos, right_pos


def sort(A, left, right):
    if left < right:
        lp, rp = partition(A, left, right)
        sort(A, left, lp - 1)
        sort(A, lp + 1, rp - 1)
        sort(A, rp + 1, right)



if __name__ == '__main__':
    A = get_arr(30)
    print("Not sorted array:")
    print(A)
    sort(A, 0, len(A) - 1)
    print("Sorted array:")
    print(A)