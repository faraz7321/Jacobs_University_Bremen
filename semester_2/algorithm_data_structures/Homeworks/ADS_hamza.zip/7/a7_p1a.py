from random import choice

def partition_lomuto(A, left, right):
    pivot = A[right]
    i = left - 1
    for j in range(left, right):
        if A[j] < pivot:
            i += 1
            A[i], A[j] = A[j], A[i]
    A[i + 1], A[right] = A[right], A[i + 1]
    return i + 1

def quick_sort_lomuto(A, left, right):
    if left < right:
        pivot = partition_lomuto(A, left, right)
        quick_sort_lomuto(A, left, pivot - 1)
        quick_sort_lomuto(A, pivot + 1, right)

numbers = list(range(1000))
def get_arr(length):
    L = []
    for i in range(length):
        L.append(choice(numbers))
    return L.copy()

if __name__ == '__main__':
    A = get_arr(10)
    print("Not sorted array:")
    print(A)
    quick_sort_lomuto(A, 0, len(A) - 1)
    print("Sorted array:")
    print(A)