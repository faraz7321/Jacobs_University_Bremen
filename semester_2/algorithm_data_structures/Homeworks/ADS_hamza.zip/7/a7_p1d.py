from a7_p1a import quick_sort_lomuto
from a7_p1b import quick_sort_hoare
from a7_p1c import quick_sort_median_of_3

import time
from random import choice

numbers = list(range(10000))

SIZE = 100000

def gen_arrays():
    arrays = []
    for i in range(100000):
        array = []
        for j in range(1000):
            array.append(choice(numbers))
        arrays.append(array.copy())
    return arrays.copy()

if __name__ == '__main__':
    print("Generating arrays")
    arrays = gen_arrays()
    print("Arrays generated")
    t1 = []
    t2 = []
    t3 = []
    i = 0
    for array in arrays:
        i += 1
        if i % 20 == 0:
            print(i)
        array_copy1 = array.copy()
        array_copy2 = array.copy()
        array_copy3 = array.copy()

        start = time.time()
        quick_sort_lomuto(array_copy1, 0, 999)
        end = time.time()
        t1.append(end - start)

        start = time.time()
        quick_sort_hoare(array_copy2, 0, 999)
        end = time.time()
        t2.append(end - start)

        start = time.time()
        quick_sort_median_of_3(array_copy3, 0, 999)
        end = time.time()
        t3.append(end - start)

    print(f"Avg. time for lomuto: {sum(t1) / 100000}")
    print(f"Avg. time for hoare: {sum(t2) / 100000}")
    print(f"Avg. time for mediaon of 3: {sum(t3) / 100000}")
