from random import choice

def partition_hoare(A, left, right):
    pivot = A[left]
    i = left - 1
    j = right + 1
    while True:
        i += 1
        while A[i] < pivot:
            i += 1
        j -= 1
        while A[j] > pivot:
            j -= 1
        
        if i >= j: return j
        A[i], A[j] = A[j], A[i]

def quick_sort_hoare(A, left, right):
    if left < right:
        pivot = partition_hoare(A, left, right)
        quick_sort_hoare(A, left, pivot)
        quick_sort_hoare(A, pivot + 1, right)

numbers = list(range(1000))
def get_arr(length):
    L = []
    for i in range(length):
        L.append(choice(numbers))
    return L.copy()

if __name__ == '__main__':
    A = get_arr(1000000)
    print("Not sorted array:")
    print(A)
    quick_sort_hoare(A, 0, len(A) - 1)
    print("Sorted array:")
    print(A)