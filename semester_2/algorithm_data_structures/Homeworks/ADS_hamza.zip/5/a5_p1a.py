from math import sqrt
import numpy as np

def fib_naive_recursive(n):
    if n == 1 or n == 0:
        return n
    return fib_naive_recursive(n-2) + fib_naive_recursive(n-1)

def fib_bottom_up(n):
    n1 = 0
    n2 = 1
    for i in range(n - 1):
        tmp = n2
        n2 = n1 + n2
        n1 = tmp
    
    return n2

def fib_closed_form(n):
    return (((1 + sqrt(5)) / 2) ** n) / sqrt(5) - (((1 - sqrt(5)) / 2) ** n) / sqrt(5)

def fib_matrix_reprezentation(n):
    m = np.matrix('1 ; 0')
    A = np.matrix('1 1 ; 1 0')
    for i in range(n - 1):
        m = A * m
    return m.item(0)

if __name__ == '__main__':
    # Return the 6'th element from the fib sequence (considering 0 1 1 2 3 5 8 ...)
    print(fib_naive_recursive(5))
    print(fib_bottom_up(5))
    print(fib_closed_form(5))
    print(fib_matrix_reprezentation(5))