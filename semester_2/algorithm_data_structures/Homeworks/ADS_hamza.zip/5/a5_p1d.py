import matplotlib.pyplot as plt

f = open("a5_p1b_table.txt", "r")
lines = f.readlines()

l1 = []
l2 = []
l3 = []
l4 = []
for i in range(1, len(lines)):
    lines[i] = lines[i].split(' ')
    while '' in lines[i]:
        lines[i].remove('')
    for j in range(len(lines[i])):
        if lines[i][j] == "NaN":
            lines[i][j] = 0
    l1.append(float(lines[i][1]))
    l2.append(float(lines[i][2]))
    l3.append(float(lines[i][3]))
    l4.append(float(lines[i][4]))

# Plot them
fig, ax = plt.subplots(4)
fig.suptitle('Fibonaci numbers')
plt.xlabel("N")
plt.ylabel("Time in miliseconds")

ax[0].plot(list(range(40)), l1, color="blue", label="Naive recursive")
ax[1].plot(list(range(40)), l2, color="red", label="Bottom-up")
ax[2].plot(list(range(40)), l3, color="green", label="Closed form")
ax[3].plot(list(range(40)), l4, color="black", label="Matrix")
ax[0].legend()
ax[1].legend()
ax[2].legend()
ax[3].legend()
plt.show()