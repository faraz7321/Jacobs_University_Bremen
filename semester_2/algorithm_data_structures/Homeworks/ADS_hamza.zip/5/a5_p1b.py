from a5_p1a import *
import signal
import time

# This is available only on UNIX systems, so if you're on windows this won't run
def signal_handler(signum, frame):
    raise Exception("Time out")

signal.signal(signal.SIGALRM, signal_handler)


s = "{:>3} {:>25} {:>25} {:>25} {:>25}"
f = open("a5_p1b_table.txt", "w")

def write(*args):
    f.write(s.format(*args))
    f.write("\n")

write("n", "Naive recursive", "Bottom-up", "Closed form", "Matrix")

for n in range(40):
    print(n)
    t1 = 0
    t2 = 0
    t3 = 0
    t4 = 0
    try:
        signal.alarm(1) # Max execution time 1 second
        start = time.time()
        fib_naive_recursive(n)
        end = time.time()
        t1 = end - start
    except e:
        t1 = "NaN"
    finally:
        signal.alarm(0)
    
    try:
        signal.alarm(1) # Max execution time 1 second
        start = time.time()
        fib_bottom_up(n)
        end = time.time()
        t2 = end - start
    except e:
        t2 = "NaN"
    finally:
        signal.alarm(0)

    try:
        signal.alarm(1) # Max execution time 1 second
        start = time.time()
        fib_closed_form(n)
        end = time.time()
        t3 = end - start
    except e:
        t3 = "NaN"
    finally:
        signal.alarm(0)

    try:
        signal.alarm(1) # Max execution time 1 second
        start = time.time()
        fib_matrix_reprezentation(n)
        end = time.time()
        t4 = end - start
    except e:
        t4 = "NaN"
    finally:
        signal.alarm(0)
    
    write(n, t1, t2, t3, t4)

f.close()