RED = 1
BLACK = 2

class Node:
    def __init__(self, value):
        self.value = value
        self.color = RED
        self.left = None
        self.right = None
        self.parent = None
    
    def uncle(self):
        if self.parent == None or self.parent.parent == None:
            return None
        if self.parent.isOnLeft():
            # Uncle is on the right
            return self.parent.parent.right
        else:
            # Uncle is on the left
            return self.parent.parent.left
    
    def isOnLeft(self):
        return self == self.parent.left
    
    def brother(self):
        if self.parent == None:
            return None
        if self.isOnLeft():
            return self.parent.right
        return self.parent.left
    
    def moveDown(self, node):
        if not self.parent == None:
            if self.isOnLeft():
                self.parent.left = node
            else:
                self.parent.right = node
        node.parent = self.parent
        self.parent = node

    def hasRedChild(self):
        return (self.left != None and self.left.color == RED) or (self.right != None and self.right.color == RED)


class RedBlackTree:
    def __init__(self):
        self._root = None
    
    def rotateLeft(self, x : Node):
        y = x.right
        x.right = y.left
        if not y.left == None:
            y.left.parent = x
        y.parent = x.parent
        if x.parent == None:
            self._root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    
    def rotateRight(self, x: Node):
        y = x.left
        x.left = y.right
        if not y.right == None:
            y.right.parent = x
        y.parent = x.parent
        if x.parent == None:
            self._root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.right = x
        x.parent = y

    def insert(self, value):
        node = Node(value)
        if self._root == None:
            node.color = BLACK
            self._root = node
            return
        
        step = self.search(value)
        if step.value == value:
            return # I DON'T WANT DUPLICATES
        
        node.parent = step
        if value < step.value:
            step.left = node
        else:
            step.right = node
        
        self._insert_fixup(node)
        
        
    def remove(self, value):
        result = self.search(value)
        if result.value == value:
            self._deleteNode(result)
            return True
        return False
    
    def search(self, value):
        """
        This function returns the node that the value is in,
        or the parent of the value if it is to be added in the tree
        """
        step = self._root
        while (step != None):
            if value < step.value:
                if step.left == None:
                    break
                step = step.left
            elif value == step.value:
                break
            else: # value > step.value
                if step.right == None:
                    break
                step = step.right
        return step

    def _insert_fixup(self, node: Node):
        if node == self._root:
            node.color = BLACK
            return
        
        parent = node.parent
        gradparent = parent.parent
        uncle = node.uncle()

        if parent.color == BLACK:
            return

        if not uncle == None and uncle.color == RED:
            parent.color = BLACK
            uncle.color = BLACK
            gradparent.color = RED
            self._insert_fixup(gradparent)
            return
        
        if parent.isOnLeft():
            if node.isOnLeft(): # LEFT LEFT
                self._swap_colors(parent, grandparent)
            else: # LEFT RIGHT
                self.rotateLeft(parent)
                self._swap_colors(node, gradparent)
            self.rotateRight(gradparent)
        else:
            if node.isOnLeft(): # RIGHT LEFT
                self.rotateRight(parent)
                self._swap_colors(node, gradparent)
            else: # RIGHT RIGHT
                self._swap_colors(parent, gradparent)
            self.rotateLeft(gradparent)

    def _successor(self, node: Node):
        step = node
        while step.left != None:
            step = step.left
        
        return step

    def _replacement(self, node):
        # 2 children
        if node.left != None and node.right != None:
            return self._successor(self.right)
        
        # leaf
        if node.left == None and node.right == None:
            return None
        
        # one kid
        if node.left == None:
            return node.right
        return node.left

    def _deleteNode(self, node):
        u = self._replacement(node)

        BLACK_nu = ((u == None or u.color == BLACK) and node.color == BLACK)
        parent = node.parent

        if u == None:
            if node == self._root:
                self._root = None
            else:
                if BLACK_nu:
                    self._doubleBlack(node)
                else:
                    if node.brother() != None:
                        node.brother().color = RED
                
                if node.isOnLeft():
                    parent.left = None
                else:
                    parent.right = None
            del node
            return
        
        if node.left == None or node.right == None:
            if node == self._root:
                node.value = u.value
                v.left = v.right = None
                del u
            else:
                if node.isOnLeft():
                    parent.left = u
                else: parent.right = u
                del node
                u.parent = parent
                if BLACK_nu:
                    self._doubleBlack(u)
                else:
                    u.color = BLACK
            return

        self._swap_values(u, node)
        self._deleteNode(u)

    def _doubleBlack(self, node):
        if node == self._root:
            return # Base case
        
        brother = node.brother()
        parent = node.parent()
        if brother == None:
            self._doubleBlack(parent)
        else:
            if brother.color == RED:
                parent.color = RED
                brother.color = BLACK
                if brother.isOnLeft():
                    self.rotateRight(parent)
                else:
                    self.rotateLeft(parent)
                self._doubleBlack(node)
            else:
                if brother.hasRedChild():
                    if brother.left != None and brother.left.color == RED:
                        if brother.isOnLeft():
                            brother.left.color = brother.color
                            brother.color = parent.color
                            self.rotateRight(parent)
                        else:
                            brother.left.color = parent.color
                            self.rotateRight(brother)
                            self.rotateLeft(parent)
                    else:
                        if brother.isOnLeft():
                            brother.right.color = parent.color
                            self.rotateLeft(brother)
                            self.rotateRight(brother)
                        else:
                            brother.right.color = borther.color
                            brother.color = parent.color
                            self.rotateLeft(parent)
                    parent.color = BLACK
                else:
                    brother.color = RED
                    if parent.color == BLACK:
                        self._doubleBlack(parent)
                    else:
                        parent.color = BLACK
    
    def _swap_values(self, a, b):
        a.value, b.value = b.value, a.value

    def _swap_colors(self, a, b):
        a.color, b.color = b.color, a.color
    
    def BFS_Print(self):
        l = []
        l.append(self._root)
        while len(l) > 0:
            print(l[0].value, end = ' ')
            if l[0].left != None:
                l.append(l[0].left)
            if l[0].right != None:
                l.append(l[0].right)
            l = l[1:]

    def INFIX_PRINT(self):
        self._INFIX_Print(self._root)

    def _INFIX_Print(self, node: Node):
        if node == None:
            return
        self._INFIX_Print(node.left)
        print(node.value, end=' ')
        self._INFIX_Print(node.right)

if __name__ == '__main__':
    numbers = [13, 44, 37, 7, 22, 16]
    RBT = RedBlackTree()
    for n in numbers:
        RBT.insert(n)
    RBT.BFS_Print()
    print()
    RBT.INFIX_PRINT()

    
    print()
    RBT.remove(16)
    RBT.BFS_Print()
    print()
    RBT.INFIX_PRINT()