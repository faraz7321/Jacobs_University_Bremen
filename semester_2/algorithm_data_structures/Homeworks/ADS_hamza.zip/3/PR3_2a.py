import random as rnd
from selection import selection

if __name__ == '__main__':
    # Generate random array
    arr = []
    arr_length = 30
    numbers_range = list(range(0, 400))
    for i in range(arr_length):
        arr.append(rnd.choice(numbers_range))

    # Print the non sorted version
    print("Not sorted array")
    print(arr)

    # Sort the thing
    selection(arr)

    # Print the sorted version
    print("Sorted array")
    print(arr)
