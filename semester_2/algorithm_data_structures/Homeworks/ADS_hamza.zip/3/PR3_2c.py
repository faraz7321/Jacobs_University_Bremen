from selection import selection
import random as rnd

# this was to help me plot stuff at 3.2d
def gen_arrays(n):
    return (list(range(2, n + 1)) + [1], list(range(1, n + 1)))

# this is the actual thing that generated random list, though in a very
# inefficiend way, like I get all the random numbers, then sort them, then put them in the order I want
# meh it will have to do
def gen_random_arrays(n):
    number_list = list(range(1, 1000000))
    l = []
    for i in range(n):
        l.append(rnd.choice(number_list))
    l.sort()
    return (l[1:] + [l[0]],  l.copy())

if __name__ == '__main__':
    n = 20
    # For the worst case senario, we can have the maximum ammount of swaps if we have
    # the last element of the array to always be the smalles element left at 
    # the right side.
    # I experimented on a paper with an example and started with a sorted array
    # and arrived at the result by "desorting it" applying selection sort
    # "in reverse"
    # 1 2 3 4 5 6 7 8
    # 1 2 3 4 5 6 8 7
    # 1 2 3 4 5 7 8 6
    # 1 2 3 4 6 7 8 5
    # 1 2 3 5 6 7 8 4
    # 1 2 4 5 6 7 8 3
    # 1 3 4 5 6 7 8 2
    # 2 3 4 5 6 7 8 1
    # The case with the least swaps would be if there are no swaps
    CASE_A, CASE_B = gen_random_arrays(n)
    # Print the non sorted version
    print("Not sorted CASE A")
    print(CASE_A)

    # Sort the thing
    selection(CASE_A)

    # Print the sorted version
    print("Sorted CASE A")
    print(CASE_A)

    # Print the non sorted version
    print("Not sorted CASEB B")
    print(CASE_B)

    # Sort the thing
    selection(CASE_B)

    # Print the sorted version
    print("Sorted CASE A")
    print(CASE_B)
