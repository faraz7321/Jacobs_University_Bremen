import matplotlib.pyplot as plt
import time
import random as rnd

from selection import selection
from PR3_2c import gen_arrays

def avg_case(n):
    l = []
    numbers = list(range(1, 1000))
    for i in range(n):
        l.append(rnd.choice(numbers))
    return l.copy()

if __name__ == '__main__':
    CASE_A_times = []
    CASE_B_times = []
    CASE_AVG_times = []

    length_range = list(range(1, 10000))

    for n in length_range:
        # Create the arrays
        CASE_A, CASE_B = gen_arrays(n)
        CASE_AVG = avg_case(n)

        # Measure time for each of them
        start = time.time()
        selection(CASE_A)
        end = time.time()
        CASE_A_times.append((end - start))


        mn = None
        start = time.time()
        selection(CASE_B)
        end = time.time()
        mn = end - start
        # Run it a couple of times and take the minimum
        for i in range(3):
            start = time.time()
            selection(CASE_B)
            end = time.time()
            if (end - start) < mn:
                mn = end - start
        CASE_B_times.append(mn)

        start = time.time()
        selection(CASE_AVG)
        end = time.time()
        CASE_AVG_times.append((end - start))
        # To see the progress
        if n % 100 == 0:
            print (n)
    
    # Plot them
    fig, ax = plt.subplots()
    fig.suptitle('Selection sort times')
    plt.xlabel("Number elements")
    plt.ylabel("Time in miliseconds")

    ax.plot(length_range, CASE_A_times, color="blue", label="Worst case")
    ax.plot(length_range, CASE_B_times, color="red", label="Best case")
    ax.plot(length_range, CASE_AVG_times, color="green", label="Average case")
    ax.legend()
    plt.show()


    