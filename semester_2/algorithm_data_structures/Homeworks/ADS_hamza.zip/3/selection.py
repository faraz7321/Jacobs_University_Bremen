# The function that sorts the array
def selection(array):
    mn = None
    mn_index = None
    step = 0
    while step < len(array):
        mn = array[step]
        mn_index = step

        step_right = step + 1
        # Find the smallest element from the rigth side
        while step_right < len(array):
            if array[step_right] < mn:
                mn_index = step_right
                mn = array[step_right]
            step_right += 1 

        # Swap the current element with the smallest element found
        tmp = array[step]
        array[step] = array[mn_index]
        array[mn_index] = tmp
        
        step += 1