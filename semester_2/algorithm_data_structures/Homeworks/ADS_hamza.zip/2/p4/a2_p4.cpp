#include <vector>
#include <iostream>
#include <algorithm>

void print(std::vector<int> &v)
{
    for (std::vector<int>::iterator it = v.begin() ;
        it != v.end(); ++it)
    {
        std::cout << *it << " ";
    }std::cout << "\n";
}

int main()
{
    std::vector<int> v;
    for (int i = 1; i <= 30; ++i)
    {
        v.push_back(i);
    }
    v.push_back(5);
    std::reverse(v.begin(), v.end());

    print(v);
    std::replace(v.begin(), v.end(), 5, 129);
    print(v);

    return 0;
}