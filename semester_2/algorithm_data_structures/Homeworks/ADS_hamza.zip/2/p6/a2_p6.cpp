#include <fstream>
#include <iostream>
#include <map>
#include <string>

int main()
{
    // Declare the map and an iterator for it in case I need it
    std::map<std::string, std::string> people;
    std::map<std::string, std::string>::iterator it;

    // Read the data from the file
    std::ifstream in("data.txt");
    while (!in.eof())
    {
        // Read the first name, last name and birth date
        std::string firstName, lastName, bDay;
        in >> firstName >> lastName >> bDay;

        std::string name = firstName + " " + lastName;
        people.insert(std::pair<std::string, std::string>(name, bDay));
    }

    bool running = true;
    while (running)
    {
        std::string query;
        std::cout << "Type a name to search or press enter to exit the program.\n";
        std::getline(std::cin, query);

        if (query.length() == 0)
        {
            running = false;
            continue;
        }

        if (people.find(query) == people.end())
        {
            std::cout << "Name not found!"; 
        }
        else
        {
            std::cout << query << " was born in " << people[query];
        }
        std::cout << "\n\n";
    }

    return 0;
}