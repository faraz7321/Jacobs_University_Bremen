#include <deque>
#include <iostream>

int main()
{
    std::deque<float> A;
    std::deque<float>::iterator it;

    float number;

    while (true)
    {
        std::cin >> number;
        if (number == 0) break;

        if (number > 0) A.push_back(number);
        else A.push_front(number);
    }

    for (it = A.begin(); it != A.end(); ++it)
    {
        std::cout << *it << " " ;
    }

    std::cout << "\n";

    it = A.begin();
    while (*it < 0) ++it;
    A.insert(it, 0);

    for (it = A.begin(); it != A.end(); ++it)
    {
        std::cout << *it;
        if (it != --A.end()) std::cout <<";";
    }

    return 0;
}