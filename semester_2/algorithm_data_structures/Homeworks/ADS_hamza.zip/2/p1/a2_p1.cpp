#include <list>
#include <iostream>
#include <fstream>

int main()
{
    // Create the lists
    std::list<int> A, B;
    std::list<int>::iterator it;

    // Read until number is 0
    int number;
    while (true)
    {
        std::cin >> number;
        if (number <= 0) break;
        
        // Put the numbers to the list
        A.push_back(number);
        B.push_front(number);
    }

    // Print list A
    for (it = A.begin(); it != A.end(); ++it)
    {
        std::cout << *it << " ";
    }

    std::ofstream out("listB.txt");
    for (it = B.begin(); it != B.end(); ++it)
    {
        out << *it << " ";
    }

    std::cout << "\n";

    // Move the first element to the end of the list on both of them
    int elem;
    elem = A.front();
    A.pop_front();
    A.push_back(elem);

    elem = B.front();
    B.pop_front();
    B.push_back(elem);

    for (it = A.begin(); it != A.end(); ++it)
    {
        std::cout << *it;
        if (it != --A.end()) std::cout << ",";
    }
    std::cout << "\n";
    for (it = B.begin(); it != B.end(); ++it)
    {
        std::cout << *it;
        if (it != --B.end()) std::cout << ",";
    }
    std::cout << "\n";

    // Merge the lists
    A.merge(B);
    // Sort the thing then print it    
    A.sort();
    for (it = A.begin(); it != A.end(); ++it)
    {
        std::cout << *it;
        if (it != --A.end()) std::cout << ",";
    }

    return 0;
}