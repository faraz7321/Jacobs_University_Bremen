#include <iostream>
#include <ctime>
#include <set>
#include <algorithm>

int get_random()
{
    return rand() % 49 + 1;
}

int main()
{
    // Set random seed
    srand(time(NULL));

    // Read and put 6 numbers to set
    std::set<int> numbers;
    while (numbers.size() < 6)
    {
        numbers.insert(get_random());
    }
    
    // Print them out
    for (std::set<int>::iterator it = numbers.begin(); it != numbers.end(); ++it)
    {
        std::cout << *it << " ";
    }

    return 0;
}