def get_digit(n, d):
    return n // (10 ** (d)) % 10

KEYS = list(range(10))

def holler_radix(arr, d):
    if len(arr) <= 1 or d < 0:
        return arr.copy()
    
    s = []
    # Get dem buckets
    buckets = {}
    for key in KEYS:
        buckets[key] = []
    for number in arr:
        key = get_digit(number, d)
        buckets[key].append(number)
    # Radix sort every bucket
    for k, b in buckets.items():
        s += holler_radix(b.copy(), d - 1)

    return s.copy()

if __name__ == '__main__':
    arr = [
        170, 45, 75, 25, 2, 24, 802, 66,
        170, 45, 75, 25, 2, 24, 802, 66,
        170, 45, 75, 25, 2, 24, 802, 66,
        170, 45, 75, 25, 2, 24, 802, 66
    ]
    print("Not sorted")
    print(arr)

    k = max(len(str(n)) for n in arr)
    
    arr = holler_radix(arr.copy(), k - 1)

    print("Sorted:")
    print(arr)
