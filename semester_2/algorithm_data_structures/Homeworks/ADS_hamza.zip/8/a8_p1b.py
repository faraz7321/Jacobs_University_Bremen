def insertion_sort(arr):
    for i in range(1, len(arr)):
        j = i
        while arr[j] < arr[j - 1] and j > 0:
            arr[j], arr[j - 1] = arr[j - 1], arr[j]
            j -= 1
    return arr.copy()

def bucket_sort(arr, bucket_count = 10):
    buckets = []
    for i in range(bucket_count):
        buckets.append([])
    # BUCKETING STUFF
    for elem in arr:
        index = int(elem * bucket_count)
        buckets[index].append(elem)

    # SORT DEM BUCKETS
    for i in range(bucket_count):
        buckets[i] = insertion_sort(buckets[i])
    
    # CONCATENATE DEM BUCKETS
    a = []
    for bucket in buckets:
        a += bucket
    return a.copy()

if __name__ == '__main__':
    arr = [0.9, 0.1, 0.6, 0.7, 0.6, 0.3, 0.1]
    print("Not sorted array:")
    print(arr)
    arr = bucket_sort(arr)
    print("Sorted array:")
    print(arr)
        