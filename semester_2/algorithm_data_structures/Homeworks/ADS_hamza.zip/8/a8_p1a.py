def counting_sort(arr, range_high):
    counting = [0] * (range_high + 1)
    for i in arr:
        counting[i] += 1
    arr = []
    for i in range(len(counting)):
        arr += [i] * counting[i]
    return arr.copy()

if __name__ == '__main__':
    arr = [9, 1, 6, 7, 6, 2, 1]
    print("Not sorted array:")
    print(arr)
    arr = counting_sort(arr, max(arr))
    print("Sorted array:")
    print(arr)
