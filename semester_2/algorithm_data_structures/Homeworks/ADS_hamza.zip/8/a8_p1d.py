if __name__ == '__main__':
    arr = ["word", "category", "cat", "new", "news", "world", "bear", "at", "work", "time"]
    n = len(arr)
    k = max([len(w) for w in arr])

    print("Not sorted:")
    print(arr)
    # I belive the professor said that radix sort is linear in the course, though it is debatable,
    # I will use it here.
    KEYS = "*abcdefghijklmnopqrtstuvwxyz"
    buckets = {}
    for l in KEYS:
        buckets[l] = []

    i = 0
    while i < k:
        letter_index = k - i - 1
        for word in arr:
            bucket_key = "*"
            if len(word) > letter_index:
                bucket_key = word[letter_index]
            buckets[bucket_key].append(word)

        arr = []
        for key in KEYS:
            for elem in buckets[key]:
                arr.append(elem)
            buckets[key] = []
        i += 1
    
    print("Sorted")
    print(arr)