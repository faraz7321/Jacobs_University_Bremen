/*
CH-231-1
WindGauge.cpp
Faraz Ahmad
fa.ahmad@jacobs-university.de
*/
#include <iostream>
#include <algorithm>
using namespace std;
